(function() {
  $(document).on('ready', function() {
    var nav_buttons;
    nav_buttons = $('nav a');
    return nav_buttons.click(function() {
      var callback, page;
      nav_buttons.removeClass('current');
      page = $(event.currentTarget).addClass('current').data('page');
      $('.info').addClass('up');
      $('.page').slideUp(100);
      callback = function() {
        return $("#" + page + ", .details").addClass('small').slideDown(100);
      };
      if ($('.details').hasClass('small')) {
        return callback();
      } else {
        return $('.details').slideUp(200, callback);
      }
    });
  });

}).call(this);
